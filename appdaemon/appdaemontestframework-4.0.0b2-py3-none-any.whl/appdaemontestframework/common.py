class AppdaemonTestFrameworkError(Exception):
    pass
